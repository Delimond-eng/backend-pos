<footer class="footer mt-auto py-3 bg-white text-center d-print-none">
    <div class="container">
        <span class="text-muted"> Copyright © <span id="year"></span> <a href="javascript:void(0);" class="text-dark fw-semibold">Rapid Tech.</a>.Democratic Republic of Congo !
        </span>
    </div>
</footer>
